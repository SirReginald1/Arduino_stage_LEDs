//
//  AppDelegate.h
//  TempoTest
//
//  Created by Michael Krzyzaniak on 9/18/21.
//  Copyright © 2021 Michael Krzyzaniak. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

